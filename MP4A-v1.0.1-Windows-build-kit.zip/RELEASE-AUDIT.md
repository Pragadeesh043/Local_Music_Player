# MP4A release preparation

## Source baseline and version

The remote default branch is `main` at `6079b780fadc8b52886998448db8a8f0f234a0e8`. The requested remote branch `developement` was verified at `4d5cc9f24823fe6c5592a3e873911453a42b778d`. The symmetric comparison returned zero main-only commits and nine development-only commits. Git advertised no tags, and the GitHub releases page reported no releases. The local proposal uses app version `1.0.1`, Windows and NSIS file version `1.0.1.0`, and tag `v1.0.1` to distinguish the public build from the reported unsigned 1.0.0.0 test installer. The previous Windows checkout and test installer were unavailable.

## Gyan Essentials evidence

The archive published by GyanD is `ffmpeg-8.0-essentials_build.zip` under release `8.0`. Its downloaded SHA-256 agrees with GitHub's asset digest. Both executables identify as `8.0-essentials_build-www.gyan.dev`. The archive README declares a static Windows x64 build and GPLv3. Embedded configure strings confirm GPL, version 3, static linking and a long list of enabled external libraries. The archive contains a GPLv3 text, a README with a build feature matrix, and HTML documentation. The README identifies FFmpeg commit `140fd653aed8cad774f991ba083e2d01e86420c7`, which is the peeled upstream `n8.0` tag. This identifies the upstream FFmpeg code cited by Gyan. The available evidence does not establish exactly which patches, revisions, and build scripts were used for every linked library or supply their complete notices. The local test installer was unavailable for byte comparison.

| Gyan 8.0 artifact | SHA-256 |
| --- | --- |
| ZIP | `647e467caf82b9fa200a562769b5ff4d736aaf725804ed2c64ea9752106fa569` |
| ffmpeg.exe | `1fcb0cb525085cc5be3ad4be16799d60786b65cc36951622a018d00f78c0fb5d` |
| ffprobe.exe | `dd315ae1b6575220f9a503343d68e55983b5bf966a43c63874f3c646dc83742f` |

Use the staged FFmpeg 8.0.3 replacement. It uses the LGPL 2.1-or-later profile, shared FFmpeg libraries, and pinned zlib for PNG. The packaging rule already copies adjacent DLLs, README and notices to `Tools\FFmpeg`, and NSIS includes them in its payload and generated uninstall list. Use the exact input ZIP, and attach the matching source tarball to the same release as the installer. The feature selection focuses on local audio, analysis and artwork. The local MP4A patch preserves WebP encoding for development builds that have it and makes the PNG fallback reachable with the smaller release bundle.

[Published Gyan asset](https://github.com/GyanD/codexffmpeg/releases/tag/8.0) · [FFmpeg 8.0 source cited by Gyan](https://github.com/FFmpeg/FFmpeg/commit/140fd653aed8cad774f991ba083e2d01e86420c7) · [FFmpeg licensing guidance](https://ffmpeg.org/legal.html)

## Historical SACD binary

Commit `765ef36` contains the 1,579,520-byte executable with Git blob ID `dd58c888e1557bca56606a3e7b8e1507377ed5`. It is reachable from both remote branches. The SHA-256 `f274f0a3845dbe6dfb2db168c0c87b15de3851256a4b5d1a804251bd809be7b3` exactly matches EuFlo's `sacd_extract-0.3.9.3-173-win64.zip` executable from release `0.3.9.3b`. Upstream identifies source commit `c9af7d40a2a186aee1763ddc4c73f60c32270f8c`. The tag contains the GPLv2 text and the executable entry point grants GPLv2 or later. The generic Windows build instructions mention pthread support and libiconv. The linked versions, settings and complete corresponding build materials for the exact upstream Windows executable remain unverified. The binary archive contains only the executable. The historical MP4A tree has an attribution and source link but no adjacent license text or complete source offer for that binary.

Commit `2112bb3` is reachable from `developement`. Its resulting tree deletes the executable and retains an updated upstream note. The current release baseline includes only opt-in SACD helper guidance. A normal promotion merge will retain the older public object. Keeping it out of the new installer limits new binary distribution.

Proposed action for approval: ask EuFlo to confirm the exact Windows build inputs and notices, then document the historical redistribution and arrange access to the complete corresponding source and applicable notices if the materials can be verified. Review what remediation is needed for existing public history with the maintainer or qualified counsel. Any history rewrite would need a separate decision, and would not remove copies already obtained by third parties.

[Binary-bearing commit](https://github.com/Pragadeesh043/Local_Music_Player/commit/765ef36) · [Removal commit](https://github.com/Pragadeesh043/Local_Music_Player/commit/2112bb3) · [EuFlo release](https://github.com/EuFlo/sacd-ripper/releases/tag/0.3.9.3b) · [EuFlo source and COPYING](https://github.com/EuFlo/sacd-ripper/tree/c9af7d40a2a186aee1763ddc4c73f60c32270f8c)

## Windows release gate

Linux verified the dependency restore, TypeScript and Vite production build, pinned FFmpeg cross-builds, PE dependency inventory, and a Linux build of the same media feature profile. The Linux media check probed a tagged FLAC, decoded and resampled it to PCM, and extracted its embedded PNG cover using the planned fallback. The Windows-targeted .NET build reached WinUI XAML compilation and failed with an executable-format error on Linux. It did not generate an installer. Windows app launch, installed child process paths, install, upgrade, playback and uninstall remain untested. Two clean Windows-targeted FFmpeg builds from the same pinned source snapshot produced byte-identical copies of both executables and all six DLLs. The input ZIP and corresponding source archive passed SHA-256 verification. Generate the installer checksum only from the Windows candidate bytes.
