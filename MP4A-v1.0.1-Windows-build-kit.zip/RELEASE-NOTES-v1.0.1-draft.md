# MP4A 1.0.1

MP4A’s first public installer is for Windows 11 x64. Install the WebView2 Evergreen Runtime if Windows does not already provide it.

- Install per user, launch MP4A from the Start menu, and remove it from Windows Installed apps.
- Browse your local library with the refreshed Discover and Now Playing views, live signal telemetry, and quicker access to DSP and output controls.
- Resume PCM playback more reliably in WASAPI shared and exclusive modes.
- Reopen albums with cached artwork and return to the previous Browse scroll position.

The installer bundles FFmpeg 8.0.3 and ffprobe for local audio and artwork. Download `MP4A-FFmpeg-8.0.3-win64-source.tar.gz` alongside the installer for matching source, build instructions, and notices. SACD ISO import requires the separately downloaded SACD helper.

For scripted installation, pass `/S`. Compare the installer against the accompanying SHA-256 file before running it.

<!-- Before publishing, enter final signature status and verify every release asset against the tested installer. -->
