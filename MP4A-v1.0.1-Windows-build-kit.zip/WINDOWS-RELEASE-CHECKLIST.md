# MP4A 1.0.1 Windows release checklist

## Build

Use Windows 11 x64 with .NET 10 SDK, Node.js 22.12+ or a supported newer version, and NSIS 3.11. The previous checkout was `D:\Project\MusicPlayer`. Use that checkout only after checking its branch, HEAD, and local changes. From a clean checkout of `4d5cc9f24823fe6c5592a3e873911453a42b778d`, run `git apply --check <path-to-patch>` and then `git apply <path-to-patch>`. Avoid overwriting local changes or the old test installer.

Verify the FFmpeg input ZIP against its local SHA-256 sidecar. Extract the contents of `Tools\FFmpeg` from that ZIP into an empty `.tools\ffmpeg` directory at the checkout root. It should contain the two x64 executables, six versioned FFmpeg DLLs, and the source instructions and license files. Save the ZIP and the matching source archive as release evidence.

```powershell
Set-Location 'D:\Project\MusicPlayer'
git status --short --branch
git rev-parse HEAD
dotnet --version
node --version
& '.\.tools\ffmpeg\ffmpeg.exe' -version
if ($LASTEXITCODE -ne 0) { throw 'FFmpeg did not start' }
& '.\.tools\ffmpeg\ffprobe.exe' -version
if ($LASTEXITCODE -ne 0) { throw 'ffprobe did not start' }
./build-app.ps1
$installer = (Resolve-Path '.\artifacts\MP4A-Setup-x64.exe').Path
if ((Get-Item -LiteralPath $installer).VersionInfo.FileVersion -ne '1.0.1.0') {
    throw 'Unexpected installer file version'
}
Get-AuthenticodeSignature -LiteralPath $installer | Select-Object Status, StatusMessage
```

## Validate the exact installer bytes

Save a clean Windows 11 x64 VM snapshot. Use a standard user and a working audio output. Enable the WebView2 Evergreen Runtime for playback testing. Confirm `where.exe ffmpeg` and `where.exe ffprobe` both fail in the account that launches MP4A. Check the app has no saved FFmpeg override and `%LOCALAPPDATA%\MP4A\Tools\FFmpeg` is absent.

| Check | Evidence to capture |
| --- | --- |
| Clean install | Installer exit code, visible MP4A 1.0.1.0 Installed apps entry and Start menu shortcut, first launch and output-device selection. |
| Tool resolution | Capture MP4A process creation events in Process Monitor or equivalent. The executable paths must be `%LOCALAPPDATA%\Programs\MP4A\Tools\FFmpeg\ffprobe.exe` and `%LOCALAPPDATA%\Programs\MP4A\Tools\FFmpeg\ffmpeg.exe` for the default install. Record the actual paths and parent's process name. |
| Import and playback | Add the tagged FLAC fixture. Confirm its title and embedded cover appear, playback is audible, and seek and pause/resume work. Record the output route and any errors. Exercise other audio formats in the user's library if available because the bundle enables a narrower codec set than Gyan Essentials. |
| Upgrade | Restore the clean snapshot. Install the original unsigned 1.0.0.0 RC baseline, create a library entry and change a setting, exit MP4A, then install 1.0.1.0 over it. Record the exit code, a single uninstall registration, retained settings and library, playback, and whether obsolete payload files are gone. |
| Uninstall | Remove MP4A through Installed apps. Check its program files, shortcut and HKCU uninstall key are gone. Check its default user data under `%LOCALAPPDATA%\Soundroom` is preserved. |
| Silent lifecycle | Repeat on a clean snapshot with installer `/S` and installed `Uninstall.exe /S`. Record exit codes and verify the same files and registry outcomes. |

Use `Start-Process -FilePath $installer -ArgumentList '/S' -Wait -PassThru` for a silent run. Record the Windows build number, commit, installer SHA-256, separate clean and upgrade results, and signature status. Retain console logs and test evidence locally.

After testing the final bytes, write the release checksum from the build checkout:

```powershell
$hash = (Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash.ToLowerInvariant()
"${hash}  MP4A-Setup-x64.exe" | Set-Content -Encoding ascii "$installer.sha256"
```

Recompute the checksum and retest the signed bytes if a later approval adds signing. Retain the unsigned test baseline separately.
