# MP4A promotion and Microsoft Store

## GitHub release sequence

Obtain separate approval before each requested external or publishing action. Resolve the historical SACD disposition before approving promotion.

1. Recheck `origin/main`, `origin/developement`, tags and releases. Inspect new commits if either branch moved. Apply `MP4A-v1.0.1-local.patch` to the reviewed development checkout with `git apply --check` followed by `git apply`. Keep local FFmpeg binaries, source archives, installer and logs outside Git.
2. Use the Windows checklist to build and validate the candidate. Save its installer and hash, the exact FFmpeg ZIP hash, the source archive hash, and the test report. Once approved, commit the reviewed files on `developement` and push `developement` to origin.
3. Once approved, open the promotion PR with `gh pr create --base main --head developement`. Include the test results, source asset link plan and SACD disposition. Require review and all configured checks.
4. After merge approval, use `gh pr merge <PR-number> --merge` if the repository allows a merge commit. Fetch `origin/main`, record its full merged SHA, and verify that the merged source tree equals the tested PR head. Build from that merged SHA and exercise the Windows checks on the exact bytes to be published. If build output changes, regenerate the checksum and use the newly tested bytes.
5. After approval, create an annotated tag `git tag -a v1.0.1 <verified-main-SHA> -m "MP4A 1.0.1"` and push `refs/tags/v1.0.1`. Once approved to create and upload the release, use `gh release create v1.0.1 --verify-tag --draft --title "MP4A 1.0.1" --notes-file RELEASE-NOTES-v1.0.1-draft.md` and attach `MP4A-Setup-x64.exe`, `MP4A-Setup-x64.exe.sha256`, and `MP4A-FFmpeg-8.0.3-win64-source.tar.gz`.
6. Check the draft's tag and asset filenames, exact hashes of the downloaded assets, source link, WebView2 notice and signature status. Publish the draft after approval.

## Microsoft Store EXE submission

1. Plan a separate Store candidate and obtain signing approval and access to Authenticode credentials whose certificate chains to a Microsoft Trusted Root Program CA.
2. Inventory all PE payloads. Verify and preserve valid trusted upstream signatures, and arrange signing for unsigned app and third-party PE payloads, including FFmpeg tools and DLLs. Timestamp signatures and account for the NSIS-generated uninstaller at package build time. Sign and timestamp the outer installer after packaging. Verify the installer and installed PE files with `signtool verify /pa /all /v` and confirm the installed uninstaller has a valid signature.
3. Test the signed installer from a clean standard-user Windows snapshot, including offline `/S` install, launch, FLAC import/playback, upgrade and uninstall. Verify WebView2 dependency behavior, and document the Evergreen prerequisite and bundled FFmpeg source. Compute SHA-256 after all signature changes.
4. After upload approval, use a direct, immutable, versioned HTTPS URL serving the exact signed EXE. Verify a fresh anonymous download and its final SHA-256. Any replacement build needs a new versioned URL.
5. In Partner Center, create or update the EXE/MSI app submission. Supply the x64 package URL, silent switch `/S`, package and listing information, and certification instructions for WebView2 and local playback. After submission approval, submit for certification and address the findings before publication.

[Microsoft package requirements](https://learn.microsoft.com/en-us/windows/apps/publish/publish-your-app/msi/app-package-requirements) · [Microsoft certification process](https://learn.microsoft.com/en-us/windows/apps/publish/publish-your-app/msi/app-certification-process)
